package com.example.CRM1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Crm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
